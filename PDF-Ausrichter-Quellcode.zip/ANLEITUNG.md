# PDF-Ausrichter für Windows

Das Programm verarbeitet alle PDF-Dateien direkt im gewählten Quellordner. Es erkennt die Leserichtung jeder Seite anhand vorhandenen PDF-Texts oder mit OCR, dreht nur die Seitenstruktur (ohne erneute Bildkomprimierung) und speichert das Ergebnis unter demselben Dateinamen im Zielordner. Die Originaldateien bleiben unverändert.

## Voraussetzungen

1. Python 3.11 oder neuer installieren und dabei **Add Python to PATH** aktivieren.
2. [Tesseract OCR für Windows](https://github.com/UB-Mannheim/tesseract/wiki) installieren. Die Standardinstallation fügt Tesseract üblicherweise dem Suchpfad hinzu.

## Direkt starten

In diesem Ordner eine Eingabeaufforderung öffnen und ausführen:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python pdf_ausrichter.py
```

Dann Quell- und Zielordner auswählen und **Verarbeitung starten** anklicken.

## EXE bauen

Nach der Installation der Pakete:

```powershell
pyinstaller --clean --noconfirm pdf_ausrichter.spec
```

Die fertige Datei liegt danach unter `dist\PDF-Ausrichter.exe`. Tesseract muss auch auf dem Zielrechner installiert sein. Alternativ kann dessen Installationsordner vor dem Start der EXE zur Windows-Umgebungsvariable `PATH` hinzugefügt werden.

## Hinweise

- Unterordner werden bewusst nicht verarbeitet.
- Seiten mit zu wenig erkennbarem Text bleiben unverändert.
- Falls im Zielordner bereits eine gleichnamige Datei liegt, wird sie erst nach erfolgreicher Verarbeitung atomar ersetzt.
- Handschriftliche, bildarme oder stark beschädigte Seiten können nicht immer zuverlässig automatisch orientiert werden.
