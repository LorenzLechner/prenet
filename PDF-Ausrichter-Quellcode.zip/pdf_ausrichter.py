from __future__ import annotations

import os
import queue
import re
import threading
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import fitz  # PyMuPDF
import pytesseract
from PIL import Image
from pypdf import PdfReader, PdfWriter


APP_TITLE = "PDF-Seiten automatisch ausrichten"


def configure_tesseract() -> None:
    """Find a standard Windows installation if tesseract is not on PATH."""
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Tesseract-OCR" / "tesseract.exe",
        Path(__file__).resolve().parent / "tesseract" / "tesseract.exe",
    ]
    for candidate in candidates:
        if candidate.is_file():
            pytesseract.pytesseract.tesseract_cmd = str(candidate)
            return


def _rotation_from_text(page: fitz.Page) -> int | None:
    """Return clockwise correction based on embedded text direction."""
    counts = {0: 0, 90: 0, 180: 0, 270: 0}
    data = page.get_text("dict")
    for block in data.get("blocks", []):
        for line in block.get("lines", []):
            chars = sum(len(span.get("text", "").strip()) for span in line.get("spans", []))
            dx, dy = line.get("dir", (1.0, 0.0))
            if chars < 2:
                continue
            if abs(dx) >= abs(dy):
                direction = 0 if dx >= 0 else 180
            else:
                direction = 90 if dy >= 0 else 270
            counts[direction] += chars
    direction = max(counts, key=counts.get)
    if counts[direction] < 20:
        return None
    return (-direction) % 360


def _rotation_from_ocr(page: fitz.Page, dpi: int = 150) -> int:
    pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72), colorspace=fitz.csRGB, alpha=False)
    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    try:
        osd = pytesseract.image_to_osd(image, config="--psm 0")
    except pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError(
            "Tesseract OCR wurde nicht gefunden. Bitte Tesseract installieren und das Programm neu starten."
        ) from exc
    except pytesseract.TesseractError:
        return 0  # Too little text: leave the page unchanged.
    match = re.search(r"Rotate:\s*(0|90|180|270)", osd)
    return int(match.group(1)) if match else 0


def detect_rotation(page: fitz.Page) -> int:
    text_rotation = _rotation_from_text(page)
    return text_rotation if text_rotation is not None else _rotation_from_ocr(page)


def process_pdf(source: Path, destination: Path, log) -> None:
    doc = fitz.open(source)
    reader = PdfReader(str(source), strict=False)
    if len(doc) != len(reader.pages):
        raise RuntimeError("Seitenzahl konnte nicht eindeutig gelesen werden.")
    rotations = [detect_rotation(page) for page in doc]
    doc.close()

    writer = PdfWriter()
    for number, (page, correction) in enumerate(zip(reader.pages, rotations), 1):
        if correction:
            page.rotate(correction)
        writer.add_page(page)
        log(f"  Seite {number}: {correction}° im Uhrzeigersinn")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    try:
        with temporary.open("wb") as stream:
            writer.write(stream)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("760x520")
        self.minsize(640, 420)
        self.source = tk.StringVar()
        self.target = tk.StringVar()
        self.status = tk.StringVar(value="Bereit")
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self._build()
        self.after(100, self._poll)

    def _build(self) -> None:
        frame = ttk.Frame(self, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=APP_TITLE, font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 14))
        for label, variable, command in (
            ("Quellordner", self.source, self._choose_source),
            ("Zielordner", self.target, self._choose_target),
        ):
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=5)
            ttk.Label(row, text=label, width=13).pack(side="left")
            ttk.Entry(row, textvariable=variable).pack(side="left", fill="x", expand=True, padx=8)
            ttk.Button(row, text="Auswählen ...", command=command).pack(side="right")
        self.progress = ttk.Progressbar(frame, mode="determinate")
        self.progress.pack(fill="x", pady=(15, 5))
        ttk.Label(frame, textvariable=self.status).pack(anchor="w")
        self.log = tk.Text(frame, height=15, state="disabled", wrap="word")
        self.log.pack(fill="both", expand=True, pady=10)
        self.start_button = ttk.Button(frame, text="Verarbeitung starten", command=self._start)
        self.start_button.pack(anchor="e")

    def _choose_source(self) -> None:
        if value := filedialog.askdirectory(title="Quellordner auswählen"):
            self.source.set(value)

    def _choose_target(self) -> None:
        if value := filedialog.askdirectory(title="Zielordner auswählen"):
            self.target.set(value)

    def _append(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _start(self) -> None:
        source, target = Path(self.source.get()), Path(self.target.get())
        if not source.is_dir() or not self.target.get():
            messagebox.showerror(APP_TITLE, "Bitte einen gültigen Quell- und Zielordner auswählen.")
            return
        if source.resolve() == target.resolve():
            messagebox.showerror(APP_TITLE, "Quell- und Zielordner müssen verschieden sein.")
            return
        target.mkdir(parents=True, exist_ok=True)
        self.start_button.configure(state="disabled")
        self.progress["value"] = 0
        threading.Thread(target=self._worker, args=(source, target), daemon=True).start()

    def _worker(self, source: Path, target: Path) -> None:
        files = sorted(source.glob("*.pdf"))
        self.events.put(("maximum", max(1, len(files))))
        if not files:
            self.events.put(("done", "Im Quellordner wurden keine PDF-Dateien gefunden."))
            return
        errors = 0
        for index, pdf in enumerate(files, 1):
            self.events.put(("status", f"Verarbeite {pdf.name} ({index}/{len(files)})"))
            self.events.put(("log", f"{pdf.name}:"))
            try:
                process_pdf(pdf, target / pdf.name, lambda text: self.events.put(("log", text)))
                self.events.put(("log", "  Fertig"))
            except Exception as exc:
                errors += 1
                self.events.put(("log", f"  FEHLER: {exc}"))
                traceback.print_exc()
            self.events.put(("progress", index))
        self.events.put(("done", f"Abgeschlossen: {len(files) - errors} erfolgreich, {errors} Fehler."))

    def _poll(self) -> None:
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "log": self._append(str(value))
                elif kind == "status": self.status.set(str(value))
                elif kind == "maximum": self.progress["maximum"] = int(value)
                elif kind == "progress": self.progress["value"] = int(value)
                elif kind == "done":
                    self.status.set(str(value)); self._append(str(value))
                    self.start_button.configure(state="normal")
                    messagebox.showinfo(APP_TITLE, str(value))
        except queue.Empty:
            pass
        self.after(100, self._poll)


if __name__ == "__main__":
    configure_tesseract()
    App().mainloop()
