# -*- mode: python ; coding: utf-8 -*-

a = Analysis(
    ["pdf_ausrichter.py"],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=["PIL._tkinter_finder"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas,
    [], name="PDF-Ausrichter", debug=False, bootloader_ignore_signals=False,
    strip=False, upx=True, console=False,
)
